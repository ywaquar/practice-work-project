import test
# Import required libraries
import sys
# Save original stdout
orig_stdout = sys.stdout
# Define the file name to save output
output_file = "output.tex"

# Open the file in write mode
f = open(output_file, 'w')
# Redirect stdout to the file
sys.stdout = f
# Define the LaTeX code to generate
latex_code = test.generate_steps_output()
print(latex_code)
# Reset stdout to its original value
sys.stdout = orig_stdout
# Close the file
f.close()