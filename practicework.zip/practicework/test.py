def get_question(loss_per, sp):
    """
    Returns the question string by formatting the given variables
    into the question template.
    """
    question_template = r"""
    A farmer sells his product at a loss of %s\%%. If his S.P. was Rs %s,
    what was his actual loss? What was his cost price?
    """
    return question_template % (loss_per, sp)


def get_answer(sp, loss_per):
    """
    Returns the answer string by calculating the cost price and loss
    using the given variables and formatting them into the answer template.
    """
    cp = (sp * 100) // (100 - loss_per)
    loss = (loss_per / 100) * cp
    answer_template = r"""
    Let the C.P. be $x$.

    We have, S.P. = Rs %s, Loss $= %s\%%$.

    Loss $= \frac{%s}{100} \times x = \frac{%sx}{%s}$.

    S.P. = C.P. - Loss,
    \begin{align*}
        %s &= x - \frac{%sx}{%s} \\
        %s &= \frac{%sx}{%s} \\
        x &= Rs %s
    \end{align*}

    Loss $= %s - %s = Rs %s$.
    """
    return answer_template % (sp, loss_per, loss_per, loss_per, 100,
                               sp, loss_per, 100,
                               sp, loss_per, 100, cp,
                               cp, sp, cp - sp)
def generate_que_answer():
    """
    Returns the question and answer strings by calling the
    get_question() and get_answer() functions.
    """
    loss_per = 15
    sp = 20000

    question = get_question(loss_per, sp)
    answer = get_answer(sp, loss_per)
    return f"{question}\n{answer}"

def get_steps():

    Steps = [
        {
            "step": r"""$$
            \text{Understand the problem and identify the given values and what needs to be found.}\\
            \text{Let the cost price of the product be } x. \\
            \text{We have S.P. = Rs } %s, \text{ Loss } = %s\%%.
            $$""",

            "verifier": r"""$$
            \text {This step is an explanation of the problem statement and doesn't require any verification. %s}
            $$""",

            "explain": r"""$$ 
            \text{Please refer back to the question. The sales price is mentioned as Rs %s and the loss\
            percentage is %s percent.}
            $$"""
        },

        {
            "step": r"""$$
            \text{Write the formula for Loss:}\\
               \text{ Loss = } \frac{%s}{100}\times
                 x=\frac{%sx}{%s}
            $$""",

            "verifier": r"""$$
            \text {To verify the second step, we can put C.P. = %s. Then we get Loss = %s.}
            $$""",

            "explain": r"""$$
            \text{The cost price is considered to be x, and the loss percentage is given as %s. We have calculated Loss as a function of x.}\\
            \text{Loss }= \frac{%sx}{100}
            $$"""
        },

        {
            "step": r"""$$
            \text{Get the equation for cost price:}\\
            \text{Write the formula for selling price:}\\
            \text{S.P. }= \text{C.P. - Loss}\\
            \text{S.P. }= \text{C.P. - Loss percentage } \times \text{ C.P.}\\
            \text{Substituting the values of S.P. = %s and Loss percentage = %s percent, we get the equation for cost price:}\\
            %s = x - \frac{%sx}{100}
            $$""",

            "verifier": r"""$$
            \text {We can verify this formula by substituting the value of C.P. = %s and Loss = %s. Then we get S.P. = %s.}
            $$""",

            "explain": r"""$$
            \text{Substitute the given values of S.P. %s and Loss %s in the above formula. We get the equation of cost price.}
            $$"""
        },

        {
            "step": r""" $$ 
            \text { Calculating the value of cost price}\\
            \text{ Solving for } x \text{, we get: }\\
            x =\frac{%s}{1- frac {%s}{100}}
            $$""",

            "verifier": r"""$$
            \text {We can verify this formula by substituting the value of C.P = %s and Loss = %s, then we get S.P = %s.}
            $$""",

            "explain": r"""$$
            \text {The selling price of the product is the price at which the farmer sold the product.\
            \As per the problem, the farmer sold the product at a loss of %s.\ 
            \So, the selling price will be the cost price minus %s percent of the cost price.}\\
            \text {The value of cost price is thus obtained as Rs %s} $$
            """
        },

        {
            "step": r""" $$ 
            \text { Calculating actual loss of the product}\\
            \text{ Actual loss } = \text{ C.P. - S.P. }\\
            \text {Substituting the values of C.P. = %s and S.P. = %s, we get:}\\
            \text{ Actual loss } = Rs %s - Rs %s = Rs %s $$
            """,

            "verifier": r"""$$
            \text {We can verify this formula by substituting C.P = %s, S.P. = %s, then we get Loss = %s}
            $$""",

            "explain": r""" $$ 
            \text{Substitute the values of C.P. = %s and S.P. = %s in the above formula to get the actual loss}\\
            \text { Actual loss of the product is Rs %s} 
            $$"""
        }]
    return Steps


def get_variables():
    CP = 120
    SP = 100
    Loss = 20
    loss_per = 15
    sp = 20000
    cp = (sp * 100) // (100 - loss_per)
    h = 5
    return CP, SP, Loss, loss_per, sp, cp, h

def step_args():
    CP, SP, Loss, loss_per, sp, cp, h = get_variables()
    # add 5 lists of step args below
    step_args = [[sp, loss_per],
                 [loss_per, loss_per // h, 100 // h],
                 [sp, loss_per, sp, loss_per // h],
                 [sp, loss_per],
                 [cp, sp, cp, sp, cp - sp]]
    return step_args

def explainer_args():
    CP, SP, Loss, loss_per, sp, cp, h = get_variables()
    # add 5 lists of explainer args below
    explainer_args = [[sp, loss_per],
                      [loss_per, loss_per],
                      [sp, loss_per],
                      [loss_per, loss_per, cp],
                      [cp, sp, cp - sp]]
    return explainer_args

def verifier_args():
    CP, SP, Loss, loss_per, sp, cp, h = get_variables()
    # add 5 lists of verifier args below
    verifier_args = [[''],
                     [CP, Loss],
                     [CP, Loss, SP],
                     [CP, Loss, SP],
                     [CP, SP, Loss]]
    return verifier_args


def generate_steps_output():
    output = ""
    gen_que_answer = generate_que_answer()
    Steps = get_steps()
    verifier_arg = verifier_args()
    explainer_arg = explainer_args()
    step_arg= step_args()
    i = 0
    for s in Steps:
        txt = s["step"] % (tuple(step_arg[i]))
        output += "Step  %s: %s\n" % (i + 1, txt)

        txt = s["verifier"] % (tuple(verifier_arg[i]))
        output += "Verification of step %s: %s\n" % (i + 1, txt)

        txt = s["explain"] % (tuple(explainer_arg[i]))
        output += "Explanation of step %s: %s\n" % (i + 1, txt)
        i += 1

    return gen_que_answer + output

if __name__ == "__main__":

    c = generate_steps_output()
    print(c)
